[![CodeFactor](https://www.codefactor.io/repository/github/ikami-mercy/niko/badge)](https://www.codefactor.io/repository/github/ikami-mercy/niko) [![Codacy Badge](https://api.codacy.com/project/badge/Grade/72ce8382256b4910b53ea71d11fbec46)](https://www.codacy.com/manual/Ikami-Mercy/Niko?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=Ikami-Mercy/Niko&amp;utm_campaign=Badge_Grade)



# Niko
Get your current location and show it in open street MAPS


### Screenshots
<img src="ScreenShots/screenone.jpeg" width="200"> <img src="ScreenShots/screentwo.jpeg" width="210">

